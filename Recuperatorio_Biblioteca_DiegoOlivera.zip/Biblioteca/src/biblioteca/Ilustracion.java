
package biblioteca;


public class Ilustracion extends Publicacion{
    private String nombreIlustrador;
    private double ancho;
    private double alto;
    
    public Ilustracion(String titulo, int anioPublicacion, String nombreIlustrador, double ancho, double alto) {
        super(titulo, anioPublicacion);
        this.nombreIlustrador = nombreIlustrador;
        this.ancho = ancho;
        this.alto = alto;
    }

    @Override
    public String toString() {
        return "Ilustracion {" + "nombreIlustrador=" + nombreIlustrador + ", ancho=" + ancho + ", alto=" + alto + '}';
    }
}
