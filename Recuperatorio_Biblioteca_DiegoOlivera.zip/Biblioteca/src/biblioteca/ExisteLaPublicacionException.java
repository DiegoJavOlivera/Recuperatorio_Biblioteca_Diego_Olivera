
package biblioteca;


public class ExisteLaPublicacionException extends RuntimeException{
    private static final String MESSAGE = "La publicacion ya existe";
    
    public ExisteLaPublicacionException(){
        super(MESSAGE);
    }
}