
package biblioteca;


public interface Leible {
    void leer();
}
