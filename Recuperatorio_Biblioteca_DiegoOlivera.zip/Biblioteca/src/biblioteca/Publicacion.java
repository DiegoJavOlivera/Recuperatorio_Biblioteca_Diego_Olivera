
package biblioteca;

import java.util.Objects;


public abstract class Publicacion {
    private String titulo;
    private int anioPublicacion;

    public Publicacion(String titulo, int anioPublicacion) {
        this.titulo = titulo;
        this.anioPublicacion = anioPublicacion;
    }

    public String getTitulo() {
        return titulo;
    }

    
    @Override
    public int hashCode() {
        return Objects.hash(titulo, anioPublicacion);
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        
        Publicacion other = (Publicacion) o;
        
        return other.titulo.equals(titulo) &&
                other.anioPublicacion == anioPublicacion;
    }
    

    @Override
    public String toString() {
        return "Publicacion{" + "titulo=" + titulo + ", anioPublicacion=" + anioPublicacion + '}';
    }
}
