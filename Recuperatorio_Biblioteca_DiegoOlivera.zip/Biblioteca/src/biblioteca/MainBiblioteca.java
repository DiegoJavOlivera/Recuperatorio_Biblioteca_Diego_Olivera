
package biblioteca;

/**
 *
 * @author Diego
 */
public class MainBiblioteca {


    public static void main(String[] args) {
        
        Biblioteca biblioteca = new Biblioteca("Biblioteca: De todo lectura\n");
        
        //profe o Feli borre los comentarios para probar el codigo por favor
        
        // sin errores
        
        try {
            System.out.println(biblioteca.getNombre());
            biblioteca.agregarPublicacion(new Libro("Pricipito", 2000, "Antoine", Genero.FICCION));
            biblioteca.agregarPublicacion(new Ilustracion("Los Andes", 2021, "San Martin", 150, 120));
            biblioteca.agregarPublicacion(new Revista("Hombres", 2014, 225));
            
        } catch (NullPointerException | ExisteLaPublicacionException | IllegalArgumentException e) {
                        System.out.println("Error!: " + e.getMessage());
        }
        
        // error duplicado
        /*
        try {
            System.out.println(biblioteca.getNombre());
            biblioteca.agregarPublicacion(new Libro("Principito", 2000, "Antoine", Genero.FICCION));
            biblioteca.agregarPublicacion(new Ilustracion("Los Andes", 2021, "San Martin", 150, 120));
            biblioteca.agregarPublicacion(new Ilustracion("Los Andes", 2021, "San Martin", 150, 120));
            biblioteca.agregarPublicacion(new Revista("Hombres", 2014, 225));
            
        } catch (NullPointerException | ExisteLaPublicacionException | IllegalArgumentException e) {
                        System.out.println("Error!: " + e.getMessage());
        }
        */
        biblioteca.mostrarPublicaciones();
        
        biblioteca.leerPublicaciones();
    }
}
