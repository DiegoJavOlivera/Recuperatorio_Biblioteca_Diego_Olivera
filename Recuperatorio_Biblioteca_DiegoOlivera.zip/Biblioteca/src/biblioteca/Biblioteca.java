
package biblioteca;

import java.util.ArrayList;
import java.util.List;


public class Biblioteca {
    private String nombre;
    private List<Publicacion> publicaciones;
    
    public Biblioteca(String nombre){
        this.nombre = nombre;
        this.publicaciones = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }
    
    
    public void agregarPublicacion(Publicacion publicacion){
        if(publicacion == null){
            throw new NullPointerException("No se puede agregar nulos");
        }
        else if(!existe(publicacion)){
            publicaciones.add(publicacion);
            System.out.println("Se agrego la publicacion " + publicacion.getTitulo());
        }
    }
    
    private boolean existe(Publicacion publicacion){
        if(publicaciones.contains(publicacion)){
            throw new ExisteLaPublicacionException();
        }
        return false;
    }
    
    public void mostrarPublicaciones(){
        for(Publicacion publicacion : publicaciones){
            System.out.println(publicacion);
        }
    }
    
    public void leerPublicaciones(){
        for(Publicacion publicacion : publicaciones){
            if(publicacion instanceof Leible l){
                l.leer();
            }
            else{
                System.out.println("Publicacion " + publicacion.getTitulo() + " no es leible.");
            }
        }
    }
}
